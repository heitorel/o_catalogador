package com.example.myapplication.collections

data class CollectionField(val fieldName: String){
}
