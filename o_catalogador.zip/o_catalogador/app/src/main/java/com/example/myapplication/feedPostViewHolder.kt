package com.example.myapplication

import com.example.myapplication.authentication.Post

data class feedPostViewHolder(val post: Post) {
}
