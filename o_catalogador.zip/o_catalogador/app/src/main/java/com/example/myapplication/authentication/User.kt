package com.example.myapplication.authentication

class User(val name: String?="",val email: String?="",val password: String?="") {

}